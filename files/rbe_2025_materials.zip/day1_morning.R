## R by Example
## Dave Armstrong
## ICPSR Summer Program
## June 2, 2025
## Day 1: Morning Session

# install.packages("rio")
library(rio)
x<-2+2
x = 2+2
z <- 3+3

# show working directory
getwd()

# set working directory
setwd("~/Dropbox/rbe_2025")

spss_dat <- import("data/r_example.sav")
spss_dat <- import('data/r_example.sav')

stata.dat <- import("data/r_example.dta")
str(spss_dat)

factorize(spss_dat)

## example
library(rio)
spss_dat <- import("data/r_example.sav")
spss_dat$x2_fac <- factorize(spss_dat$x2)
spss_dat

str(spss_dat)

library(skimr)
skim_without_charts(spss_dat)

stata2.dat <- import("data/r_example_miss.dta")
stata2.dat$x2 <- factorize(stata2.dat$x2)

stata2.dat <- import("data/r_example_miss.dta")
stata2.dat$x2_fac <- factorize(stata2.dat$x2)
stata2.dat

mean(stata2.dat$x1) # evaluates to missing
mean(stata2.dat$x1, na.rm=TRUE) # removes missings then calculates
mean(stata2.dat$x1, na.rm=FALSE) # doesn't remove missing values

stata2.dat.lwd <- na.omit(stata2.dat) # listwise deletes entire dataset
mean(stata2.dat.lwd$x1)

spss_dat$x3 == "yes"

stata2.dat$x1 == 1

spss_dat$x2_fac == "none"

spss_dat$x2_fac == 1 # doesn't work because R wants you to use the label, not the number.

gss <- import("data/GSS2016.dta")
gss              
gss[ , c("age", "partyid")]

## rio workflow
str(gss[ , c("age", "partyid")])
attr(gss$partyid, "labels") <-  attr(gss$partyid, "labels")[1:8]
gss$partyid_fac <- factorize(gss$partyid)
skim_without_charts(gss[ , c("age", "partyid", "partyid_fac")])

## Import Dataset Button (haven)
str(GSS2016[ , c("age", "partyid")])
GSS2016$partyid_fac <- as_factor(GSS2016$partyid)
skim_without_charts(GSS2016[ , c("age", "partyid", "partyid_fac")])

              
# find where a function is located (what package it is in)
getAnywhere(as_factor)                            


## Recap from Morning
# 1. Download data.zip and extract

#### 2.  do once per version of R
# install.packages("rio")

#### 3. do each R session where you want to use the functions
# library(rio)

#### 4. Import data - save to object
# data_name <- import("path/to/data")

#### Alternatively, use import dataset button

install.packages("tidyverse")
## tidyverse 
## dplyr 

library(tidyverse)

gss <- import("data/GSS2016.dta")
attr(gss$partyid, "labels") <-  attr(gss$partyid, "labels")[1:8]

gss <- gss %>%
  mutate(partyid_fac = factorize(partyid))

gss %>% select(age, partyid, partyid_fac)
gss %>% 
  summarise(age = mean(age, na.rm=TRUE))

pid_sum <- gss %>% 
  group_by(partyid_fac) %>% 
  summarise(n = n()) %>%  
  drop_na() %>% 
  mutate(pct = n/sum(n))

## import button produces data frame GSS2016
GSS2016 <- GSS2016 %>%
  mutate(partyid_fac = as_factor(partyid))

pid_sum <- GSS2016 %>% 
  group_by(partyid_fac) %>% 
  summarise(n = n()) %>%  
  drop_na() %>% 
  filter(partyid_fac != "NA") %>% 
  mutate(pct = n/sum(n)) 


## multi-line pipe :)
age_sum <- gss %>% 
  group_by(partyid_fac) %>% 
  summarise(mean_age = mean(age, na.rm=TRUE), 
            mean_sei = mean(sei10, na.rm=TRUE)) %>%  
  drop_na() 

## one-line pipe :\
age_sum <- gss %>% group_by(partyid_fac) %>% summarise(mean_age = mean(age, na.rm=TRUE), mean_sei = mean(sei10, na.rm=TRUE)) %>%  drop_na() 

## nested functions :(
drop_na(summarise(group_by(gss, partyid_fac), mean_age = mean(age, na.rm=TRUE), mean_sei = mean(sei10, na.rm=TRUE)))

gss <- gss %>%
  mutate(sex = factorize(sex))

age_gen_sum <- gss %>% 
  group_by(partyid, sex) %>% 
  summarise(mean_age = mean(age, na.rm=TRUE), 
            mean_sei = mean(sei10, na.rm=TRUE)) %>%  
  drop_na() 

pid_gen_freq <- gss %>% 
  group_by(partyid_fac, sex) %>% 
  summarise(n = n()) %>% 
  drop_na() %>% 
  group_by(partyid_fac) %>%
  mutate(pct = n/sum(n))

GSS2016 <- GSS2016 %>%
  mutate(partyid_fac = as_factor(partyid), 
         sex= as_factor(sex))
GSS2016 %>% 
  group_by(partyid_fac, sex) %>% 
  summarise(n = n()) %>% 
  filter(partyid_fac != "NA") %>% 
  drop_na() %>% 
  group_by(partyid_fac) %>%
  mutate(pct = n/sum(n))


## making factors "by hand"
gss <- import("data/GSS2016.dta")
attr(gss$partyid, "labels") <-  attr(gss$partyid, "labels")[1:8]

gss <- gss %>%
  mutate(partyid_fac = factorize(partyid))

gss <- gss %>% 
  mutate(sex_f = factor(sex, 
                        levels=c(1,2), 
                        labels=c("male", "female")))

gss <- gss %>% 
  mutate(partyid_fac2 = factor(partyid, 
                               levels=c(0,1,2,3,4,5,6,7), 
                               labels=c("D", "D", "D", "I", "R", "R", "R", "O")))


library(ggplot2)

ggplot(gss, aes(x=partyid_fac)) +
  geom_bar() +
  scale_x_discrete(labels=c("SD", "D", "LD", 
                            "I", "LR", "R", "SR", "O", "NA"))

ggplot(gss %>% filter(partyid_fac != "O" & !is.na(partyid_fac)), 
       aes(x=partyid_fac))  +
  geom_bar() + 
  scale_x_discrete(labels=c("SD", "D", "LD", 
                            "I", "LR", "R", "SR"))

## Exercise

library(tidyverse)

gss <- import("data/GSS2016.dta")

gss <- gss %>% 
  mutate(sparts = factorize(sparts))


attr(gss$sparts, "labels") <- na.omit(attr(gss$sparts, "labels"))
gss <- gss %>% 
  mutate(sparts = factorize(sparts))


attr(gss$aidhouse, "labels") <- na.omit(attr(gss$aidhouse, "labels"))
attr(gss$newsfrom, "labels") <- na.omit(attr(gss$newsfrom, "labels"))

gss <- gss %>% 
  mutate(sparts = factorize(sparts), 
         aidhouse = factorize(aidhouse), 
         newsfrom = factorize(newsfrom)) 


# with import button 
attr(GSS2016$sparts, "labels") <- na.omit(attr(GSS2016$sparts, "labels"))
attr(GSS2016$aidhouse, "labels") <- na.omit(attr(GSS2016$aidhouse, "labels"))
attr(GSS2016$newsfrom, "labels") <- na.omit(attr(GSS2016$newsfrom, "labels"))

GSS2016 <- GSS2016 %>% 
  mutate(sparts = as_factor(sparts), 
         aidhouse = as_factor(aidhouse), 
         newsfrom = as_factor(newsfrom)) 



ggplot(gss %>% filter(!is.na(sparts)), 
       aes(x=sparts)) + 
  geom_bar() + 
  theme(axis.text.x = element_text(angle=45, hjust=1)) + 
  labs(x = "Preferences for Spending on the Arts")


ggplot(gss %>% filter(!is.na(sparts)), 
       aes(x=sparts)) + 
  geom_bar() + 
  theme(axis.text.x = element_text(angle=45, hjust=1)) + 
  labs(x = "") + 
  ggtitle("Preferences for Spending on the Arts")

ggplot(gss %>% filter(!is.na(newsfrom)), aes(x=newsfrom)) + 
  geom_bar()

tmp <- gss %>% 
  group_by(newsfrom) %>% 
  summarise(n=n()) %>% 
  na.omit() %>% 
  mutate(newsfrom = reorder(newsfrom, n, I))

ggplot(tmp, aes(x=newsfrom, y=n)) + 
  geom_bar(stat="identity") + 
  theme(axis.text.x = element_text(angle=45, hjust=1)) + 
  labs(x = "") 
  
gss <- gss %>%
  mutate(newsfrom_small = case_when(
    newsfrom == "the internet" ~ "Internet", 
    newsfrom == "tv" ~ "TV", 
    newsfrom == "newspapers" ~ "Newspapers", 
    #newsfrom == "family" | newsfrom == "friends colleagues" ~ "Other people"
    newsfrom %in% c("family", "friends colleagues") ~ "Other people", 
    is.na(newsfrom) ~ NA_character_,
    TRUE ~ "Other Sources"
  ), 
  newsfrom_small = factor(newsfrom_small))
tmp <- gss %>% 
  group_by(newsfrom_small) %>% 
  summarise(n=n()) %>% 
  na.omit() %>% 
  mutate(newsfrom_small = reorder(newsfrom_small, n, I))

ggplot(tmp, aes(x=newsfrom_small, y=n)) + 
  geom_bar(stat="identity") + 
  theme(axis.text.x = element_text(angle=45, hjust=1)) + 
  labs(x = "") 

ggplot(gss %>% filter(!is.na(aidhouse)), aes(x=aidhouse)) + 
  geom_bar() + 
  theme(axis.text.x = element_text(angle=45, hjust=1)) 
  
## reverse order of factor
ggplot(gss %>% filter(!is.na(aidhouse)), aes(x=fct_rev(aidhouse))) + 
  geom_bar() + 
  theme(axis.text.x = element_text(angle=45, hjust=1)) 

tmp <- gss %>% 
  group_by(newsfrom) %>% 
  summarise(n=n()) %>% 
  na.omit() %>% 
  mutate(newsfrom = reorder(newsfrom, n, I))

ggplot(tmp, aes(x=newsfrom, y=n)) + 
  geom_bar(stat="identity") + 
  theme_bw() + 
  theme(axis.text.x = element_text(angle=45, hjust=1)) + 
  labs(x = "") 

ggplot(tmp, aes(x=newsfrom, y=n)) + 
  geom_bar(stat="identity") + 
  theme_classic() + 
  theme(axis.text.x = element_text(angle=45, hjust=1)) + 
  labs(x = "") 

ggplot(tmp, aes(x=newsfrom, y=n)) + 
  geom_bar(stat="identity") + 
  theme_bw() + 
  theme(axis.text.x = element_text(angle=45, hjust=1),
        panel.grid = element_blank()) + 
  labs(x = "") 

ggplot(tmp, aes(x=newsfrom, y=n)) + 
  geom_bar(stat="identity") + 
  theme_bw() + 
  theme(axis.text.x = element_text(angle=45, hjust=1),
        panel.grid = element_line(linetype="dotted")) + 
  labs(x = "") 

ggplot(tmp, aes(x=newsfrom, y=n)) + 
  geom_bar(stat="identity") + 
  theme_bw() + 
  theme(axis.text.x = element_text(angle=45, hjust=1)) + 
  labs(x = "") +
  coord_flip()

attr(gss$partyid, "labels") <-  attr(gss$partyid, "labels")[1:8]
gss$partyid_fac <- factorize(gss$partyid)

age_sum <- gss %>% 
  group_by(partyid_fac) %>% 
  summarise(mean_cl_normal(age)) %>%  
  drop_na() 

ggplot(age_sum, aes(x=partyid_fac, y = y, 
                    ymin =ymin, ymax=ymax)) + 
  geom_bar(stat="identity") + 
  geom_linerange() +
  coord_flip()

ggplot(age_sum, aes(x=partyid_fac, y = y, 
                    ymin =ymin, ymax=ymax)) + 
  geom_bar(stat="identity") + 
  geom_errorbar(width = .25) +
  coord_flip()

## Exercise

# g <- gss
# rm(gss)

tmp_sei1 <- gss %>% 
  group_by(sparts) %>% 
  summarise(sei10 = mean(sei10, na.rm = TRUE)) %>%
  na.omit()

ggplot(tmp_sei1, aes(x=sparts, y=sei10)) + 
  geom_bar(stat="identity") + 
  theme_bw()

tmp_sei1a <- gss %>% 
  group_by(sparts) %>% 
  summarise(mean_cl_normal(sei10)) %>%
  na.omit()

ggplot(tmp_sei1a, aes(x=sparts, y=y, ymin=ymin, ymax=ymax)) + 
  geom_bar(stat="identity") + 
  geom_errorbar(width=.1) + 
  theme_bw()


tmp_sei2 <- gss %>% 
  group_by(newsfrom_small) %>% 
  summarise(sei10 = mean(sei10, na.rm = TRUE)) %>%
  na.omit()

ggplot(tmp_sei2, aes(x=reorder(newsfrom_small, sei10), y=sei10)) + 
  geom_bar(stat="identity") + 
  theme_bw()


tmp_sei2a <- gss %>% 
  group_by(newsfrom_small) %>% 
  summarise(mean_cl_normal(sei10)) %>%
  na.omit()

ggplot(tmp_sei2a, aes(x=reorder(newsfrom_small, y), y=y, ymin = ymin, ymax = ymax)) + 
  geom_bar(stat="identity") + 
  geom_errorbar(width=.1) + 
  theme_bw()

tmp_sei3 <- gss %>% 
  group_by(aidhouse) %>% 
  summarise(sei10 = mean(sei10, na.rm = TRUE)) %>%
  na.omit()

ggplot(tmp_sei3, aes(x=aidhouse, y=sei10)) + 
  geom_bar(stat="identity") + 
  theme_bw()

tmp_sei3a <- gss %>% 
  group_by(aidhouse) %>% 
  summarise(mean_cl_normal(sei10)) %>%
  na.omit()

ggplot(tmp_sei3a, aes(x=aidhouse, y=y, ymin = ymin, ymax = ymax)) + 
  geom_bar(stat="identity") + 
  geom_errorbar(width=.1) + 
  theme_bw()


## France_2004.dta
## demsat - satisfaction with democracy
## lrself - left-right self-placement (0=ext. left, 10=ext. right)
## age 

## 1. make a bar plot of demsat (counts)
## 2. bar plot of mean of lrself by demsat
## 3. bar plot of mean of age by demsat
## extra challenge - include 95% confidence intervals

library(rio)
library(tidyverse)

## read in data
france <- import("data/France_2004.dta")
france %>% select(demsat, lrself, age) %>% str()

france <- france %>% 
  mutate(demsat = factor(demsat, 
                         levels=1:4, 
                         labels=c("Very", "Somewhat", "A little", "Not at all")))

table(france$demsat)

ggplot(france, aes(x=demsat)) + 
  geom_bar() + 
  theme_bw()






