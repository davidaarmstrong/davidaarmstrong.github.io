## R by Example
## Dave Armstrong
## ICPSR Summer Program
## June 3, 2025
## Day 2
library(tidyverse)
library(haven)

## Haven Workflow
colo <- read_dta("data/colo_dat_cs.dta")

colo %>% select(urban_rural) %>% str()

colo <- colo %>%
  mutate(urbrurf = as_factor(urban_rural))

table(colo$urbrurf)

## rio Workflow
library(rio)
colo_r <- import("data/colo_dat_cs.dta")
colo <- colo %>%
  mutate(urbrurf = factorize(urban_rural))

table(colo$urbrurf)


## bar plot of urban rural factor

ggplot(colo, aes(x=urbrurf)) + 
  geom_bar() + 
  theme_bw() + 
  labs(x="", y = "Frequency") + 
  coord_flip() 

urdat <- colo %>% 
  group_by(urbrurf) %>% 
  summarise(n = n()) %>% 
  mutate(urbrurf = reorder(urbrurf, n))

ggplot(urdat, aes(x=urbrurf, y=n)) + 
  geom_bar(stat="identity") + 
  theme_bw() + 
  labs(x="", y = "Frequency") + 
  coord_flip() 

mhdat <- colo %>%
  group_by(urbrurf) %>% 
  summarise(mean_mh = mean(mental_health, na.rm=TRUE)) %>% 
  na.omit() 

ggplot(mhdat, aes(x=urbrurf, y =mean_mh)) + 
  geom_bar(stat="identity") + 
  theme_bw() + 
  labs(x="", y="Average Number of Poor Mental Health Days\nOut of the last 30 Days") + 
  coord_flip()

mhdat <- mhdat %>% 
  mutate(urbrurf = reorder(urbrurf, mean_mh))

ggplot(mhdat, aes(x=urbrurf, y =mean_mh)) + 
  geom_bar(stat="identity") + 
  theme_bw() + 
  labs(x="", y="Average Number of Poor Mental Health Days\nOut of the last 30 Days") + 
  coord_flip()

## investigate properties of variables
colo %>% select(urban_rural, mental_health) %>% str()


tmp <- colo
tmp$mental_health[1] <- NA
ggplot(tmp, aes(x=reorder(urbrurf, mental_health, mean), 
                 y=mental_health)) + 
  stat_summary(geom="bar", fun=mean) + 
  theme_bw() + 
  labs(x="", y="Average Mental Health Score") + 
  coord_flip()


rvdat <- colo %>% 
  group_by(urbrurf) %>% 
  summarise(mean_rv = mean(repvote, na.rm=TRUE)) %>% 
  na.omit() %>% 
  mutate(urbrurf = reorder(urbrurf, mean_rv))

library(scales)

ggplot(rvdat, aes(x=urbrurf, y=mean_rv)) +
  geom_bar(stat="identity") + 
  theme_bw() + 
  labs(x="", y="Republican Share of Two-party Vote") + 
  coord_flip() + 
  scale_y_continuous(labels = label_percent())

ggplot(rvdat, aes(x=urbrurf, y=mean_rv)) +
  geom_bar(stat="identity") + 
  theme_bw() + 
  labs(x="", y="Republican Share of Two-party Vote") + 
  coord_flip() + 
  scale_y_continuous(breaks = c(0, .25, .5, .75, 1), 
                     labels = label_percent(), 
                     limits=c(0,1)) 

## truncating the range of the axis removes elements that extend beyond the limit. 
ggplot(rvdat, aes(x=urbrurf, y=mean_rv)) +
  geom_bar(stat="identity") + 
  theme_bw() + 
  labs(x="", y="Republican Share of Two-party Vote") + 
  coord_flip() + 
  scale_y_continuous(breaks = c(0, .25, .5, .75, 1), 
                     labels = label_percent(), 
                     limits=c(0,.5)) 

## Using Colors
ggplot(colo, aes(x=repvote)) + 
  geom_histogram(bins = 5, color="white", fill = "#5e3c99")

ggplot(colo, aes(x=repvote)) + 
  geom_histogram(bins = 5, color="white", fill = rgb(178,171,210, maxColorValue = 255))

## make democratic/republican county factor

colo <- colo %>% 
  mutate(rep_county = case_when(
    repvote < .5 ~ "Democratic", 
    repvote >= .5 ~ "Republican", 
    TRUE ~ NA_character_
    # if numbers on RHS of tilde, then NA_real_, NA_integer_
  ))

## If no missing data on repvote, then
colo <- colo %>% 
  mutate(rep_county = case_when(
    repvote < .5 ~ "Democratic", 
    TRUE ~ "Republican"
  ))

colo <- colo %>% 
  mutate(dir_county = case_when(
    repvote < .45 ~ "Democratic", 
    repvote > .55 ~ "Republican",
    TRUE ~ "Independent"
  ))

## Common Errors
## can't find function X: forgot to load package or typed function name wrong
## object X not found: misspell object name or looking for object you forgot to make
## unexpected string/numeric constant: usually forgot a comma

urdat <- colo %>%
  group_by(urbrurf) %>% 
  summarise(n = n()) %>% 
  na.omit() 

mhdat <- colo %>%
  group_by(urbrurf) %>% 
  summarise(mean_mh = mean(mental_health, na.rm=TRUE)) %>% 
  na.omit() 

rvdat <- colo %>%
  group_by(urbrurf) %>% 
  summarise(mean_rv = mean(repvote, na.rm=TRUE)) %>% 
  na.omit() 
  
group_dat <- colo %>% 
  group_by(urbrurf) %>%
  summarise(n = n(), 
            mean_mh = mean(mental_health, na.rm=TRUE), 
            mean_rv = mean(repvote, na.rm=TRUE)) 


group_dat <- urdat %>% 
  left_join(mhdat) %>% 
  left_join(rvdat)

## 4 commonly used join functions

## left_join(x,y) or x %>% left_join(y)
###### keep all obs in x and matching obs from y
## right_join(x,y) or x %>% right_join(y)
###### keep all obs in y and matching obs from x
## full_join(x,y) or x %>% full_join(y)
###### keep all obs in x and y
## inner_join(x,y) or x %>% inner_join(y)
###### keep all obs common to both x and y
## anti_join(x,y) or x %>% anti_join(y)
###### returns x, but only the observations that do not appear in y
## semi_join(x,y) or x %>% anti_join(y)
###### returns x, but only the observations that appear in y

x <- data.frame(letters = c("A", "B", "C"), w = 1:3)
y <- data.frame(letters = c("B", "C", "D"), z= 4:6)

left_join(x,y)
right_join(x,y)
full_join(x,y)
inner_join(x,y)
anti_join(x,y)
semi_join(x,y)


x1 <- data.frame(letters = c("A", "B", "C"), w = 1:3, m=7:9)
y1 <- data.frame(letters = c("B", "C", "D"), z= 4:6, m=10:12)

full_join(x1, y1, by=join_by(letters))

x2 <- data.frame(lettersx = c("A", "B", "C"), w = 1:3)
y2 <- data.frame(lettersy = c("B", "C", "D"), z= 4:6)
full_join(x2, y2, by=join_by(lettersx == lettersy))

x3 <- data.frame(letters = rep(c("A", "B", "C"), c(3,4,5)), 
                 num = 1:12)
y3 <- data.frame(letters=c("A", "B", "C"), v = 2:4)
left_join(x3, y3)
right_join(x3, y3)

left_join(x3, y)

x4 <- data.frame(letters = rep(c("A", "B", "C"), each=2), 
                 num = 1:6)
y4 <- data.frame(letters = rep(c("A", "B", "C"), each=2), 
                               m = 1:6)
x4 <- left_join(x4, y4)                 

## back to the scheduled program

table(colo$rep_county)
table(colo$dir_county)

ggplot(colo %>% filter(rep_county == "Democratic"), 
       aes(x=mental_health)) + 
  geom_histogram(bins=5) + 
  theme_bw()

ggplot(colo %>% filter(rep_county == "Republican"), 
       aes(x=mental_health)) + 
  geom_histogram(bins=5) + 
  theme_bw()

## baseline
ggplot(colo, 
       aes(x=mental_health)) + 
  geom_histogram(bins=5) + 
  theme_bw() + 
  facet_wrap(~rep_county)

## column instead of row orientation
ggplot(colo, 
       aes(x=mental_health)) + 
  geom_histogram(bins=5) + 
  theme_bw() + 
  facet_wrap(~rep_county, ncol=1)

## adapt y-axis to highest value in panel
ggplot(colo, 
       aes(x=mental_health)) + 
  geom_histogram(bins=5) + 
  theme_bw() + 
  facet_wrap(~rep_county, ncol=1, scales="free_y")

## row instead of column orientation
ggplot(colo, 
       aes(x=mental_health)) + 
  geom_histogram(bins=5) + 
  theme_bw() + 
  facet_wrap(~rep_county, nrow=1)

ggplot(colo, 
       aes(x=mental_health)) + 
  geom_histogram(bins=5) + 
  theme_bw() + 
  facet_wrap(~rep_county, nrow=1, scales="free_x")

ggplot(colo, 
       aes(x=mental_health)) + 
  geom_histogram(bins=5) + 
  theme_bw() + 
  facet_wrap(~rep_county, nrow=1, scales="free")

## why does it fail without "scales=", why do I get an error
## about ncol 
ggplot(colo, 
       aes(x=mental_health)) + 
  geom_histogram(bins=5) + 
  theme_bw() + 
  facet_wrap(~rep_county, nrow=1, "free")

## stacked is the default
ggplot(colo, 
       aes(x=mental_health, fill=rep_county)) + 
  geom_histogram(bins=5) + 
  theme_bw() 

## plot both starting at 0
## color brewer palette
ggplot(colo, 
       aes(x=mental_health, fill=rep_county)) + 
  geom_histogram(bins=5, position = "identity", alpha=.5) + 
  theme_bw() +
  scale_fill_brewer(palette = "Dark2")

## specify colors manually
ggplot(colo, 
       aes(x=mental_health, fill=rep_county)) + 
  geom_histogram(bins=5, position = "identity", alpha=.5, color="white") + 
  theme_bw() +
  scale_fill_manual(values=c("olivedrab2","mediumorchid2" ))

## make a new factor for phys_health >= 3.35 vs < 3.35
## make a histogram of mental_health for these two 
##   different values of physical health factor


colo <- colo %>% 
  mutate(phfac = case_when(
          phys_health >= 3.35 ~ "Unhealthy", 
          phys_health < 3.35 ~ "Healthy", 
          TRUE ~ NA_character_), 
         phfac = factor(phfac, levels=c("Unhealthy", "Healthy")))

ggplot(colo, aes(x=mental_health)) + 
  geom_histogram(bins=8) + 
  theme_bw() + 
  facet_wrap(~phfac, nrow=1)


ggplot(colo, aes(x=mental_health, fill=phfac)) + 
  geom_histogram(bins=8, position="identity", alpha=.4) + 
  theme_bw() + 
  scale_fill_manual(values=c("blue", "orange")) +
  theme(legend.position = "top") + 
  labs(x="Mentally Unhealthy Days", y="Count", fill="Physical Health")

colo <- colo %>% 
  mutate(phfac = case_when(
    phys_health >= 3.35 ~ "Unhealthy", 
    phys_health < 3.35 ~ "Healthy", 
    TRUE ~ NA_character_))

ggplot(colo, aes(x=mental_health)) + 
  geom_histogram(bins=8) + 
  theme_bw() + 
  facet_wrap(~dir_county, ncol=2)


ggplot(colo, aes(y=mental_health, x=phfac)) + 
  geom_boxplot() 

ggplot(colo, aes(y=mental_health, x=phfac)) + 
  geom_boxplot() +
  facet_wrap(~rep_county)

ggplot(colo, aes(y=mental_health, x=phfac)) + 
  geom_violin() + 
  stat_summary(geom="point", fun=mean) + 
  stat_summary(geom="point", fun=median, color="red")

ggplot(colo, aes(y=mental_health, x=phfac)) + 
  geom_violin() +
  stat_summary(geom="errorbar", fun.data=mean_cl_normal, width=.1) 
  

ggplot(colo, aes(y=mental_health, x=phfac)) + 
  stat_summary(geom="errorbar", fun.data=mean_cl_normal, width=.1) +
  geom_violin(fill="transparent") 

## Scatterplots

ggplot(colo, aes(x=BAplus, y =  wkly_wage)) + 
  geom_point() + 
  scale_x_continuous(labels = label_percent())

## add a trend line
library(scales)
ggplot(colo, aes(x=BAplus, y =  wkly_wage)) + 
  geom_point() + 
  geom_smooth(method="lm", se=TRUE, color="black") + 
  scale_x_continuous(labels = label_percent())

ggplot(colo, aes(x=BAplus, y =  wkly_wage)) + 
  geom_point(shape=5) + 
  geom_smooth(method="lm", se=FALSE, color="red", fullrange=TRUE) + 
  scale_x_continuous(labels = label_percent()) + 
  facet_wrap( ~ rep_county)

ggplot(colo, aes(x=BAplus, y =  wkly_wage, shape=rep_county, color=rep_county, linetype=rep_county)) + 
  geom_point() + 
  geom_smooth(method="lm", se=FALSE, fullrange=TRUE) + 
  scale_x_continuous(labels = label_percent()) + 
  scale_color_manual(values=c("Blue", "Red")) + 
  scale_shape_manual(values=c(1,4))

ggplot(colo, aes(x=BAplus, y =  wkly_wage, alpha = rep_county)) + 
  geom_point() + 
  geom_smooth(method="lm", se=TRUE, fullrange=TRUE) + 
  scale_x_continuous(labels = label_percent()) + 
  scale_alpha_manual(values=c(1, .25))

ggplot(colo, aes(x=BAplus, y=wkly_wage, label=county)) + 
  geom_text() + 
  theme_bw()

colo <- colo %>% 
  mutate(lbl = case_when(
    wkly_wage > 1200 | wkly_wage < 625 ~ county, 
    TRUE ~ NA_character_
  ))

ggplot(colo, aes(x=BAplus, y=wkly_wage, label=lbl)) + 
  geom_point() + 
  geom_text(position = position_nudge(y=40)) + 
  theme_bw()

install.packages("plotly")
colo <- colo %>% 
  mutate(label = paste("\nCounty: ", county, "\nBA or Greater: ", round(BAplus, 2)*100, 
                       "\nWeekly Wage: ", wkly_wage, sep="")) 

library(plotly)
g1 <- ggplot(colo, aes(x=BAplus, y=wkly_wage, text=label)) + 
  geom_point() + 
  theme_bw() + 
  labs(x="% with BA Degree or Higher", 
       y="Average Weekly Wage") 
pl1 <- ggplotly(g1, tooltip = "text")

install.packages("htmlwidgets")

# save plotly plot to html file
htmlwidgets::saveWidget(pl1,file="plotly_plot.html", selfcontained = TRUE)

ggplot(colo, aes(x=gt100k, y=phys_health)) + 
  geom_point() + 
  geom_smooth(method="gam", se=FALSE) + 
  theme_bw()

data(mtcars)

mod <- lm(qsec ~ hp  + disp, data=mtcars)

newdat <- data.frame(hp = seq(50, 330, length=25), disp = 200)
preds <- predict(mod, newdata=newdat, se.fit=TRUE)
newdat$fit <- preds$fit
newdat$lwr <- preds$fit - 2*preds$se
newdat$upr <- preds$fit + 2*preds$se


ggplot(newdat, aes(x=hp, y=fit, ymin=lwr, ymax=upr)) + 
  geom_line() + 
  geom_ribbon(alpha=.25)


load("data/covid_060923.rda")

covid_sum <- covid %>% 
  group_by(date) %>% 
  summarise(cases = sum(cases, na.rm=TRUE)) %>% 
  mutate(lag_cases =  lag(cases))

ggplot(covid_sum, aes(x=date, y=cases)) + 
  geom_line()


ggplot(covid_sum, aes(x=date, y=new_cases)) + 
  geom_line()

ggplot(covid_sum, aes(x=date, y=new_cases)) + 
  geom_line(color="gray85", linewidth=.15) + 
  geom_smooth(method="loess", color="red", se=FALSE, span=.15) + 
  theme_classic()


covid_sum <- covid %>% 
  group_by(date) %>% 
  summarise(deaths = sum(deaths, na.rm=TRUE), 
            cases = sum(cases, na.rm=TRUE)) %>% 
  mutate(new_cases = cases - lag(cases), 
         new_deaths = deaths - lag(deaths))

ggplot(covid_sum, aes(x=date, y=deaths)) + 
  geom_line() 

covid_sum <- covid_sum %>% 
  mutate(new_deaths = case_when(
    new_deaths > 0 ~ new_deaths, 
    TRUE ~ 0
  ))


ggplot(covid_sum, aes(x=date, y=new_deaths)) + 
  geom_line(color="gray85", linewidth=.15) + 
  geom_smooth(method="loess", span=.1, col="red", se=FALSE) + 
  theme_classic()


colo_covid <- covid %>% filter(state == "Colorado")
cc_sum <- colo_covid %>% 
  group_by(county) %>% 
  summarise(cases = max(cases, na.rm=TRUE), 
            date = max(date))

cc_sum %>% 
  arrange(desc(cases)) %>% 
  filter(row_number() <= 5)

worst5 <- cc_sum %>% 
  arrange(desc(cases)) %>% 
  slice_max(cases, n=5)

colo5 <- colo_covid %>% 
  filter(county %in% worst5$county) %>% 
  mutate(county = reorder(county, cases, max))

ggplot(colo5,aes(x=date, y=cases, colour=county)) + 
  geom_line() + 
  guides(color = guide_legend(reverse=TRUE))


ggplot(colo5,aes(x=date, y=cases, colour=county)) + 
  geom_line(show.legend = FALSE) +
  geom_text(data=worst5, aes(x=date, y=cases, label=county), show.legend = FALSE, 
            hjust = 0) + 
  scale_x_date(expand=c(.25,0))
  
colo5 %>% 
  ggplot(aes(x=date, y=cases, colour=county)) + 
  geom_line(show.legend = FALSE) +
  theme_bw() + 
  scale_y_continuous(
    sec.axis = sec_axis(~., 
                        breaks=worst5$cases, 
                        labels = worst5$county)) + 
  theme(legend.position="top") +
  scale_x_date(limits=c(ymd("2020-03-15"), max(covid$date)), 
               expand=c(0,0)) +
  labs(x="Date", y="COVID-19 Cases", colour="")


covid_sum %>% filter(new_deaths < 0)
covid_sum %>% filter(date > ymd("2022-03-10") & date < ymd("2022-03-20"))

ggplot(colo, aes(x=BAplus, y=wkly_wage, colour=repvote, size=log(tpop))) + 
  geom_point() + 
  geom_smooth(se=TRUE, alpha=.25, show.legend=FALSE) + 
  scale_colour_viridis_c() +
  facet_wrap(~dir_county) + 
  theme_bw() + 
  labs(x = "Proportion with BA Degree or Higher", 
       y="Weekly Wage)", 
       colour="% Republican", 
       size="Total Population (log)")

wvs_sum <- wvs %>% 
  group_by(state_abb) %>%
  summarise(sacsecval = mean(sacsecval, na.rm=TRUE), 
            resemaval = mean(resemaval, na.rm=TRUE))

wvs_sum <- wvs_sum %>% 
  pivot_longer(c(sacsecval, resemaval), names_to = "vbl", values_to = "vals") %>% 
  mutate(vbl = factor(vbl, 
                      levels = c("resemaval", "sacsecval"), 
                      labels = c("Emancipative", "Secular")))

ggplot(wvs_sum, aes(x=state_abb, y=vals, fill=vbl)) + 
  geom_bar(position = "dodge", stat="identity") + 
  coord_flip() + 
  theme(axis.text.y = element_text(size=5),
        legend.position = "top") + 
  labs(y= "Country Average", x="", fill = "Values")
ggsave("country_values.png", height=20, width=12, 
       units="in", dpi=300)


install.packages("remotes")
library(remotes)
install_github("davidaarmstrong/DAMisc", force=TRUE)

library(DAMisc)

gss2016can <- gss2016can  %>% 
  mutate(SRH_115 = factorize(SRH_115))


xt(gss2016can, "SRH_115")
table(gss2016can$SRH_115)
gss2016can %>% 
  group_by(SRH_115) %>% 
  summarise(n = n())
xtabs(~SRH_115, data=gss2016can)

gss16 %>% select(partyid, aidhouse) %>% str()

gss16 <- gss16 %>% 
  mutate(partyid = factorize(partyid), 
         aidhouse = factorize(aidhouse)) 

xt(gss16, "partyid")  
xt(gss16, "aidhouse")  

## load the ces19.rda file
## 1. Make the scatterplot of market (market liberalism) and moral (moral traditionalism) by (facet or color by) educ (education).
## 2. Make a boxplot of market by union
## 3. make a histogram of leader_lib (liberal leader feeling thermometer) by retrocan (retrospective national economic evaluations). 

load("data/ces19.rda")

ces19 %>% select(moral, market, educ) %>% str()

ggplot(ces19, aes(x=moral, y=market)) + 
  geom_point() + 
  facet_wrap(~educ) + 
  theme_bw()

ggplot(ces19 %>% filter(!is.na(educ)), aes(x=moral, y=market)) + 
  geom_point(alpha=.1) + 
  facet_wrap(~educ) + 
  theme_bw()


ces19 %>% select(market, union) %>% str()


ggplot(ces19 %>% filter(!is.na(union)), aes(x=union, y=market)) + 
  geom_boxplot() + 
  labs(x="Union Member?", y="Market Liberalism")

ces19 %>% select(leader_lib, retrocan) %>% str()

ggplot(ces19 %>% filter(!is.na(retrocan)), aes(x=leader_lib)) + 
  geom_histogram(bins = 8) + 
  facet_wrap(~retrocan)


wvs_sum <- wvs %>% 
  group_by(state_abb) %>%
  summarise(sacsecval = mean_cl_normal(sacsecval), 
            resemaval = mean_cl_normal(resemaval)) %>% 
  unnest(c(sacsecval, resemaval), names_sep = ".") %>% 
  filter(row_number() %in% 1:10)

wvs_sum <- wvs_sum %>% 
  pivot_longer(-state_abb, names_pattern = "(.*)\\.(.*)", names_to = c("vbl", ".value")) %>% 
  mutate(vbl = factor(vbl, 
                      levels = c("resemaval", "sacsecval"), 
                      labels = c("Emancipative", "Secular")))

ggplot(wvs_sum, aes(x=state_abb, y=y, ymin = ymin, ymax=ymax, color=vbl, fill=vbl)) + 
  geom_bar(position = "dodge", stat="identity", color="transparent", alpha=.25) + 
  geom_errorbar(position = position_dodge(width=1), width=.25) + 
  coord_flip() + 
  theme(axis.text.y = element_text(size=5),
        legend.position = "top") + 
  labs(y= "Country Average", x="", fill = "Values", color="Values")
