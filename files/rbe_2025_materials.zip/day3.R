## R by Example
## Dave Armstrong
## ICPSR Summer Program
## June 4, 2025
## Day 3

library(tidyverse)
## load the ces19.rda file
## 1. Make the scatterplot of market (market liberalism) and moral (moral traditionalism) by (facet or color by) educ (education).
## 2. Make a boxplot of market by union
## 3. make a histogram of leader_lib (liberal leader feeling thermometer) by retrocan (retrospective national economic evaluations).
load("~/Dropbox/rbe_2025/data/ces19.rda")

ces19 %>% select(market, moral, educ) %>% str()

ggplot(ces19, aes(x=market, y=moral)) +
  geom_point(position = position_jitter(width = .01, height=.01))

ggplot(ces19 %>% filter(!is.na(educ)), aes(x=market, y=moral)) +
  geom_point(alpha=.1) +
  geom_smooth(method="lm", se=TRUE) +
  facet_wrap(~educ) +
  theme_bw()

str(ces19$union)

ggplot(ces19 %>% filter(!is.na(union)), aes(x=union, y=market)) +
  geom_boxplot()

ggplot(ces19 %>% filter(!is.na(retrocan)), aes(x=leader_lib)) +
  geom_histogram(bins=10) +
  facet_wrap(~retrocan)

ggplot(ces19 %>% filter(!is.na(retrocan)), aes(x=leader_lib, fill=retrocan)) +
  geom_histogram(bins=10, alpha=.15, position="identity") +
  theme_bw()

# install.packages("ggridges")
library(ggridges)

## histogram
ggplot(ces19 %>% filter(!is.na(retrocan)), aes(x=leader_lib, y=retrocan)) +
  geom_density_ridges(stat="binline", bins=10, scale=.95) +
  labs(x="Liberal Feeling Thermometer", y="") + theme_bw()

## kernel density
ggplot(ces19 %>% filter(!is.na(retrocan)), aes(x=leader_lib, y=retrocan)) +
  geom_density_ridges(scale=.95) +
  labs(x="Liberal Feeling Thermometer", y="") + theme_bw()

load("~/Dropbox/rbe_2025/data/gss2016can_2025.rda")

# install.packages("remotes")
# remotes::install_github("davidaarmstrong/DAMisc")
library(DAMisc)

gss2016can <- gss2016can %>%
  mutate(SRH_110 = rio::factorize(SRH_110))

sumStats(gss2016can, "resilience", byvar=c("SRH_115", "SRH_110"))

install.packages("gmodels")
library(gmodels)
CrossTable(x = gss2016can$SRH_115, gss2016can$SRH_110, prop.t = FALSE, prop.r=FALSE, prop.chisq=FALSE)

xt(gss2016can, "SRH_115", byvar="SRH_110")

## partyid (partisan identification) and aidhouse (Government should provide housing for poor)

load("~/Dropbox/rbe_2025/data/gss16.rda")

gss16 %>% select(partyid, aidhouse) %>% str()

library(rio)
gss16 <- gss16 %>%
  mutate(partyid = factorize(partyid),
         aidhouse = factorize(aidhouse))

gss16 %>% select(partyid, aidhouse) %>% str()

xt(gss16, "aidhouse", byvar="partyid")
CrossTable(gss16$partyid, gss16$aidhouse, prop.t=FALSE, prop.r=TRUE, prop.chisq=FALSE, prop.c=FALSE)

srh_sum <- gss2016can %>%
  group_by(SRH_110, SRH_115) %>%
  summarise(n=n()) %>%
  na.omit()

ggplot(srh_sum, aes(x=SRH_115, y=SRH_110, fill=n)) +
  geom_tile() +
  scale_fill_viridis_c() +
  labs(x="Mental Health", y="Overall Health", fill="N")

## Cell Percentages

srh_sum %>%
  ungroup %>%
  mutate(prop = n/sum(n)) %>%
  ggplot(aes(x=SRH_115, y=SRH_110, fill=prop)) +
  geom_tile() +
  scale_fill_viridis_c() +
  labs(x="Mental Health", y="Overall Health", fill="N")


## Row Percentages

srh_sum %>%
  ungroup %>%
  group_by(SRH_110) %>%
  mutate(prop = n/sum(n)) %>%
  ggplot(aes(x=SRH_115, y=SRH_110, fill=prop)) +
  geom_tile() +
  scale_fill_viridis_c() +
  labs(x="Mental Health", y="Overall Health", fill="N")

## Column Percentages

srh_sum %>%
  ungroup %>%
  group_by(SRH_115) %>%
  mutate(prop = n/sum(n)) %>%
  ggplot(aes(x=SRH_115, y=SRH_110, fill=prop)) +
  geom_tile() +
  scale_fill_viridis_c() +
  labs(x="Mental Health", y="Overall Health", fill="N")

## with text

srh_sum %>%
  ungroup %>%
  group_by(SRH_115) %>%
  mutate(prop = n/sum(n),
         pct = prop*100,
         txcol = case_when(
           pct < 30 ~ "light",
           TRUE ~ "dark")) %>%
  ggplot(aes(x=SRH_115, y=SRH_110, fill=prop)) +
  geom_tile(show.legend=FALSE) +
  geom_text(aes(label = paste(round(pct), "%", sep=""),
                col=txcol),
            show.legend=FALSE) +
  scale_fill_viridis_c() +
  labs(x="Mental Health", y="Overall Health", fill="N") +
  scale_color_manual(values=c("gray30", "gray85"))

pid_sum <- gss16 %>%
  group_by(partyid, aidhouse) %>%
  summarise(n=n()) %>%
  na.omit()




pid_sum %>%
  ungroup %>%
  mutate(prop = n/sum(n),
         pct = prop*100,
         txcol = case_when(
           pct <= 4.5 ~ "light",
           TRUE ~ "dark")) %>%
  ggplot(aes(x=aidhouse, y=partyid, fill=prop)) +
  geom_tile(show.legend=FALSE) +
  geom_text(aes(label = paste(round(pct,1), "%", sep=""), color=txcol),
            show.legend=FALSE) +
  theme(axis.text.x = element_text(angle=45, hjust=1)) +
  scale_fill_viridis_c() +
  scale_color_manual(values=c("gray25", "gray85"))

ggplot(ces19, aes(x=moral, y=market)) +
  geom_hex(bins=8) +
  scale_fill_viridis_c()

ggplot(ces19, aes(x=moral, y=market)) +
  geom_density_2d_filled(h=c(.4,.4)) +
  scale_fill_viridis_d()


data(mtcars)
R <- cor(mtcars, use="pair")
heatmap(R)
# heatmap of data is only useful for really small datasets.
# heatmap(as.matrix(mtcars))
library(haven)
colo <- read_dta("data/colo_dat_cs.dta")

colo <- colo %>%
  mutate(cases_10k = cases*10000/tpop)

mod1 <- lm(cases_10k ~ white_pop, data=colo)
summary(mod1)

summary(mtcars)

ggplot2:::summary.ggplot

##shows you the code inside a function.
getAnywhere("summary.ggplot")


mod1 <- lm(cases_10k ~ white_pop + lt25k, data=colo)
mod0a <- lm(cases_10k ~ white_pop , data=colo)
mod0b <- lm(cases_10k ~ lt25k, data=colo)
coef(mod1)
vcov(mod1)
residuals(mod1)
fitted(mod1)

install.packages("stargazer")
library(stargazer)


stargazer(mod0a, mod0b, mod1,
          type="html",
          covariate.labels=c("White Population Proportion", "Proportion Earning < $25k/year", "Intercept"),
          star.cutoffs = c(.05, .01, .001),
          out="table.html")


stargazer(mod0a, mod0b, mod1,
          type="latex",
          covariate.labels=c("White Population Proportion", "Proportion Earning < $25k/year", "Intercept"),
          star.cutoffs = c(.05, .01, .001),
          out="table.tex")

stargazer(mod1, type="text",
          covariate.labels=c("White Population Proportion", "Proportion Earning < $25k/year", "Intercept"),
          star.cutoffs = .05,
          notes = "* p < .05",
          notes.append=FALSE)

install.packages("modelsummary")
library(modelsummary)
modelsummary(list(mod0a, mod0b, mod1))

install.packages("sjPlot")
library(sjPlot)
tab_model(mod0a, mod0b, mod1)


colo <- colo %>%
  mutate(rich_poor = as_factor(rich_poor))

colo <- colo %>%
  mutate(rich_poor2 = relevel(rich_poor, ref="< $1000"))

mod2 <- lm(cases_10k ~ white_pop + rich_poor, data=colo)

mod2 <- lm(cases_10k ~ white_pop + rich_poor2, data=colo)

## use gss16
## aid_scale is dv
## ivs: age, sei10, realinc, partyid, sex

gss16 %>%
  select(aid_scale, age, sei10, realinc, partyid, sex) %>%
  str()

gss16 <- gss16 %>%
  mutate(sex = factorize(sex))

ivs1 <- c("age", "sei10", "realinc", "partyid", "sex")
ivs2 <- c("age", "sei10", "realinc", "partyid", "sex", "educ")

iv_list <- list(mod1 = c("age", "sei10", "realinc", "partyid", "sex"),
                mod2 = c("age", "sei10", "realinc", "partyid", "sex", "educ"))

mods <- lapply(iv_list, \(x)lm(reformulate(x, response="aid_scale",), data=gss16))
lapply(mods, summary)


gss_mod1 <- lm(reformulate(ivs1, response="aid_scale"), data=gss16)
gss_mod2 <- lm(reformulate(ivs2, response="aid_scale"), data=gss16)



gss_mod <- lm(aid_scale ~ age + sei10 + realinc +
                partyid + sex, data=gss16)

gss_mod2 <- lm(aid_scale ~ educ + age + sei10 + realinc +
                partyid + sex , data=gss16)

summary(gss_mod)

stargazer(gss_mod, gss_mod2, type="text")

stargazer(gss_mod, gss_mod2, type="text",
          covariate.labels=c("Years of Education", "Age", "SES Index", "Income",
                            "Part ID: Dem", "Party ID: Lean Dem",
                            "Party ID: Ind", "Party ID: Lean Rep",
                            "Party ID: Rep", "Party ID: Strong Rep",
                            "Party ID: Other",
                            "Sex: Female", "Intercept"),
          notes = c("Party ID: Reference = Strong Dem",
                    "Party ID Model 1: F(7, 1187) = 25.0, p < 0.001",
                    "Party ID Model 2: F(7, 1186) = 25.1, p < 0.001",
                    "Sex: Reference = Male"),
          notes.append = TRUE)

install.packages("car")
library(car)
Anova(gss_mod)

mod2 <- lm(log(cases_10k) ~ white_pop + rich_poor, data=colo)

## to use white population squared in the model
mod2 <- lm(log(cases_10k) ~ I(white_pop^2) + rich_poor, data=colo)

## poly(x, order) does not permit missing data
## poly(x, order) does orthogonal polynomials. 
mod3 <- lm(log(cases_10k) ~ poly(white_pop, 2) + rich_poor, 
           data=subset(colo, !is.na(white_pop)))
## raw polynomial
mod3 <- lm(log(cases_10k) ~ poly(white_pop, 2, raw=TRUE) + rich_poor, 
           data=subset(colo, !is.na(white_pop)))

install.packages("marginaleffects")
library(marginaleffects)

## using by
s <- seq(.9019, .9472, by=.005)

## using length
s <- seq(.9019, .9472, length=25)


preds3 <- avg_predictions(mod3, variables = "white_pop", trans=exp)
preds3a <- predictions(mod3, newdata = datagrid(rich_poor = "$750 - $1000"), variables="white_pop")

preds3s <- predictions(mod3, 
                       newdata = datagrid(rich_poor = "$750 - $1000"), 
                       variables=list("white_pop" = s))

preds3sb <- predictions(mod3, 
                        newdata = datagrid(rich_poor = levels(colo$rich_poor), 
                                           grid_type = "counterfactual"), 
                        variables=list("white_pop" = s), 
                        by=c("white_pop", "rich_poor"))

hypotheses(preds3, "b5-b4 = 0")


ggplot(preds3sb, aes(x=white_pop, y=estimate, ymin=conf.low, ymax=conf.high)) + 
  geom_line(aes(color=rich_poor)) +
  geom_ribbon(aes(fill=rich_poor), alpha=.1)



plot_predictions(mod3, condition = "white_pop", trans=exp)

comparisons(mod3, 
            newdata = datagrid(white_pop = .9), 
            variables=list("rich_poor" = "pairwise"))


## Use the log of real income (realinc)
## generate the effects and first differences for realinc and partyid
gss_mod <- lm(aid_scale ~ age + sei10 + realinc +
                partyid + sex, data=gss16)


gss_mod <- lm(aid_scale ~ age + sei10 + log(realinc) +
                partyid + sex, data=gss16)

ri_seq <- seq(min(gss16$realinc, na.rm = TRUE), 
              max(gss16$realinc, na.rm = TRUE), 
              length = 25)

ri_preds <- predictions(gss_mod, 
                        newdata = "median",
                        variables = list(realinc = ri_seq))
library(scales)
plot_predictions(gss_mod, newdata = "mean", condition = "realinc") +
  scale_x_continuous(labels = label_number(scale_cut = cut_short_scale()))

ri_comp <- comparisons(gss_mod, 
                       newdata = "mean", 
                       variables = list(realinc = quantile(gss16$realinc, c(.1, .9), na.rm=TRUE)))


plot_predictions(gss_mod, newdata = "mean", condition = "partyid") + 
  coord_flip()

pid_preds <- predictions(gss_mod, newdata="mean", variables="partyid")

## predictions and comparisons output behave kind of like models
coef(pid_preds)
vcov(pid_preds)

pid_comp <- comparisons(gss_mod, 
                        newdata = "mean", 
                        variables = list("partyid" = "pairwise"))

pid_comp <- pid_comp %>% 
  as.data.frame() %>% 
  mutate(adjusted_p = p.adjust(p.value, "bonferroni"))

pid_comp %>% filter(adjusted_p < .05)

## 
# aov() estimating an anova for analysis
# anova()
## anova(mod) does Type I (sequential test) on variables.
## anova(mod0, mod1) does F-test for difference between nested model
# Anova(mod) [car package] does Type II and Type III tests, type=2 or type=3

## linearity problems
# crPlot [car package]
mod2 <- lm(log(cases_10k) ~ white_pop + rich_poor, data=colo)

crPlot(mod2, "white_pop", smooth = list(smoother=loessLine, 
                                       smoother.args=list(var=TRUE)))
avPlot(mod2, "white_pop")

boxTidwell(log(cases_10k) ~ wkly_wage, ~rich_poor + white_pop, data=colo)

mod2a <- lm(log(cases_10k) ~ I(wkly_wage ^ -1) + white_pop + rich_poor, data=colo)

plot_predictions(mod2a, condition = "wkly_wage", trans=exp)

mod2b <- lm(cases_10k ~ I(wkly_wage ^ -1) + white_pop + rich_poor, data=colo)

powerTransform(mod2b, "bcPower")

mod2c <- lm(bcPower(cases_10k, lambda = -.307) ~ I(wkly_wage ^ -1) + white_pop + rich_poor, data=colo)



x <- 3
x <- x + 2
x/6

myfun <- function(a){
  a <- a+2
  a/6
}


myfun(3)
myfun(7)
tfun <- function(x)bcnPowerInverse(x, -.307, gamma=0)

plot_predictions(mod2c, condition="wkly_wage", trans = tfun)

ncvTest(mod2c)
install.packages(c("lmtest", "sandwich"))
library(lmtest)
library(sandwich)

mod2c <- lm(bcPower(cases_10k, lambda = -.307) ~ I(wkly_wage ^ -1) + white_pop + rich_poor, data=colo)

coeftest(mod2c, vcov. = vcovHC, type="HC3")

load("~/Dropbox/rbe_2025/data/wvs6.rda")

str(wvs)
tmp <- wvs %>% dplyr::select(moral, age, soc_class, state_abb) %>% na.omit()
wvs_mod <- lm(moral ~ age + soc_class, data=tmp)
coeftest(wvs_mod, vcov.= vcovCL, cluster = tmp$country)


library(stringr)
colo <- colo %>% 
  mutate(urban_rural = factorize(urban_rural)) %>% 
  mutate(mur = str_extract(urban_rural, "Metro|UP|Rural"), 
         mur = factor(mur, levels=c("Rural", "UP", "Metro")), 
         rep_maj = factor(repvote > .5, 
                          levels=c(FALSE,TRUE), 
                          labels=c("No", "Yes")))

mod4 <- lm(log(cases_10k) ~ rep_maj*white_pop + mur, data=colo)
summary(mod4)

slopes(mod4, newdata= "mean", variables="white_pop", by="rep_maj")

plot_predictions(mod4, newdata="mean", by=c("white_pop", "rep_maj")) + 
  geom_point(data = colo, 
             aes(x=white_pop, y = 6.5, color = rep_maj), 
             alpha=.25, 
             # inherit.aes=FALSE, 
             position = position_jitter(height=.1)) + 
  theme_bw()

comp <- comparisons(mod4, newdata = "mean", variables="rep_maj", by="white_pop")

comp %>% filter(p.value < .05)

gss16 <- gss16 %>% mutate(tax = factorize(tax))
gss_mod <- lm(aid_scale ~ tax*sei10 + log(realinc) +
                partyid + sex, data=gss16)

table(gss16$tax)

gss16 <- gss16 %>% mutate(tax = droplevels(tax))
gss_mod <- lm(aid_scale ~ tax*sei10 + log(realinc) +
                partyid + sex, data=gss16)

slopes(gss_mod, newdata="mean", variables="sei10", by="tax")

plot_predictions(gss_mod, newdata= "mean", by = c("sei10", "tax")) + theme_bw() + 
  geom_point(data = gss16, 
             aes(x=sei10, colour=tax, y = -1.1), 
             alpha=.25, 
             position = position_jitter(height=.1),
             show.legend = FALSE) 
  

plot_predictions(gss_mod, newdata= "mean", by = c("sei10", "tax")) + theme_bw() + 
  geom_point(data = gss16 %>% filter(tax == "too high"), aes(x=sei10, colour=tax, y = -1.1), alpha=.25, position = position_jitter(height=.025)) +
  geom_point(data = gss16 %>% filter(tax == "about right"), aes(x=sei10, colour=tax, y = -1.175), alpha=.25, position = position_jitter(height=.025)) +
  geom_point(data = gss16 %>% filter(tax == "too low"), aes(x=sei10, colour=tax, y = -1.25), alpha=.25, position = position_jitter(height=.025)) 
  
tax_comps <- comparisons(gss_mod, newdata = datagrid(sei10 = c(26, 46, 65)), variables = list("tax" = "pairwise"))
hypotheses(tax_comps, "b1-b2=0")

mod4 <- lm(log(cases_10k) ~ white_pop*BAplus + rep_maj, data=colo)
summary(mod4)

DAintfun2(mod4, 
          c("white_pop", "BAplus"), 
          rug=FALSE, 
          hist=TRUE, 
          scale.hist = .3)

s1 <- slopes(mod4, newdata="mean", variables="white_pop", by="BAplus")

ggplot(s1, aes(x=BAplus, y=estimate, ymin=conf.low, ymax=conf.high)) + 
  geom_line() + 
  geom_ribbon(alpha=.25)




gss16 %>% 
  mutate(tax = droplevels(tax)) %>% 
  group_by(tax) %>% 
  summarise(mean = mean(sei10, na.rm=TRUE))




mod3 <- lm(log(cases_10k) ~ poly(white_pop, 2, raw=TRUE) + rich_poor, 
           data=subset(colo, !is.na(white_pop)))

s <- seq(.9019, .9472, length=25)
preds3a <- predictions(mod3, newdata = "mean", variables=list("white_pop" = s))

ggplot(preds3a, aes(x=white_pop, y=estimate, ymin=conf.low, ymax = conf.high)) +
  geom_ribbon(alpha=.15) + 
  geom_line() + 
  theme_bw()


plot_predictions(mod3, condition = list("white_pop" =s)) + 
  theme_bw()





