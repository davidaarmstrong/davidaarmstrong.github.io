## R by Example
## Dave Armstrong
## ICPSR Summer Program
## June 5, 2025
## Day 4

# Now, do the following:
# 
# - Make a new variable loginc which is the log of realinc 
#   and replace log(realinc) with loginc in your model.
# - Instead of an interaction between tax and sei10, use an 
#   interaction between sei10 and loginc.
# - Evaluate the interaction.

library(tidyverse)
library(rio)
load("~/Dropbox/rbe_2025/data/gss16.rda")
gss16 <- gss16 %>% 
  mutate(tax = factorize(tax), 
         sex = factorize(sex),
         partyid = factorize(partyid),
         loginc = log(realinc))
gss_mod <- lm(aid_scale ~ tax + sei10*loginc +
                partyid + sex, data=gss16)

summary(gss_mod)

library(DAMisc)
DAintfun2(gss_mod, 
          c("sei10", "loginc"), 
          rug=FALSE, 
          hist = TRUE, 
          scale.hist = .3)

changeSig(gss_mod, c("sei10", "loginc"))

DAintfun(gss_mod, c("sei10", "loginc"), theta=135)

## GLMs
dat <- read_dta("data/Davenport_Soule_ASR.dta") %>% 
  ## chose variables we need for the model
  dplyr::select(police1, afam, arrdum, police5, 
         pre65, iblackpre65, ny, south, logpart, 
         propdam, counterd, standard2, extcont2, 
         govtarg, stratvar, viold, evyy) %>%
  ## turn afam into a factor
  mutate(afam = factor(afam, labels=c("No","Yes"))) %>% 
  ## keep only those where police were present
  filter(police1 == 1) %>% 
  ## listwise delete
  na.omit()

mod <- glm(arrdum ~  poly(evyy,3) + afam  + ny + south + 
             logpart + propdam + counterd + standard2 + 
             extcont2 + govtarg + stratvar + viold, 
           data=dat, family=binomial(link="logit"))
summary(mod)


# Using the 2016 GSS data again:
#   
# - Make a new variable called inews from newsfrom that is 1 if the respondent 
#   gets news primarily from the internet and 0 for any other source. 
#   Make sure to keep the missing values missing.
# - Make a variable called college_ed from educ which is coded such that 
#   0-12 = none, 13:15 = some and 16+ = degree.
# - Estimate and summarise a logit model of inews on age, sei10, college_ed and sex.

library(tidyverse)
load("data/gss16.rda")

# look at levels of newsfrom to figure out how to recode.
# attr(gss16$newsfrom, "labels")

gss16 <- gss16 %>% 
  select(newsfrom, educ, age, sei10, sex) %>% 
  mutate(sex = factorize(sex),
         inews = case_when(
           newsfrom == 3 ~ 1, 
           newsfrom %in% c(1:2, 4:10) ~ 0, 
           TRUE ~ NA_integer_), 
         college_ed = case_when(
           educ <= 12 ~ "None", 
           educ %in% 13:15 ~ "Some", 
           educ >= 16 ~ "Degree", 
           TRUE ~ NA_character_), 
         college_ed = factor(college_ed, levels=c("None", "Some", "Degree"))) 

gmod <- glm(inews ~ college_ed + sex + sei10 + age, 
            data= gss16, family=binomial)
summary(gmod)

# install.packages("broom")
library(broom)
tidy(gmod)

library(DAMisc)

binfit(mod)
pre(mod)

install.packages("pROC")
library(pROC)
roc(dat$arrdum ~ predict(mod, type="response"), 
    print.auc=TRUE, plot=TRUE)


binfit(gmod)
pre(gmod)

## Data Frame -> 
# Model Frame (Data w/ transformations) -> 
# Model Response (y) & Model Matrix (X)


model.response(model.frame(gmod))

roc(model.response(model.frame(gmod)) ~ predict(gmod, type="response"), 
    print.auc=TRUE, plot=TRUE)

tmp <- get_all_vars(formula(gmod), gss16) %>% na.omit()

tmp %>% 
  group_by(college_ed) %>% 
  summarise(n=n())

tmp <- gss16 %>% filter(complete.cases(gss16 %>% select(inews, college_ed, sex, sei10, age))) 
table(tmp$newsfrom, useNA="ifany")


tidy(mod) %>% 
  filter(!str_detect(term, "poly")) %>% 
  mutate(or = exp(estimate))


dat2 <- read_dta("data/Davenport_Soule_ASR.dta") %>% 
  mutate(state1 = tolower(state1)) %>% 
  filter(state1 != "") %>% 
  ## chose variables we need for the model
  dplyr::select(state1, police1, afam, arrdum, police5, 
                pre65, iblackpre65, ny, south, logpart, 
                propdam, counterd, standard2, extcont2, 
                govtarg, stratvar, viold, evyy) %>%
  ## turn afam into a factor
  mutate(afam = factor(afam, labels=c("No","Yes"))) %>% 
  ## keep only those where police were present
  filter(police1 == 1) %>% 
  ## listwise delete
  na.omit()

mod2 <- glm(arrdum ~  poly(evyy,3) + afam  + ny + south + 
             logpart + propdam + counterd + standard2 + 
             extcont2 + govtarg + stratvar + viold, 
           data=dat2, family=binomial(link="logit"))

library(lmtest)
library(sandwich)
## multiwayvcov package does slightly different multi-way clustering

coeftest(mod2, vcov.=vcovCL, cluster=dat2$state1)

library(marginaleffects)

comp <- comparisons(mod, newdata="median", comparison = "difference") %>% 
  as.data.frame() %>% 
  mutate(type = "comparisons")
ave_comp <- avg_comparisons(mod, comparison = "difference") %>% 
  as.data.frame() %>% 
  mutate(type = "avg_comparisons")
comps <- bind_rows(comp, ave_comp)

ggplot(comps, aes(x=term, y=abs(estimate), fill=type)) + 
  geom_bar(position="dodge", stat="identity") + 
  coord_flip()


comparisons(mod2, newdata="median", comparison = "difference", 
            vcov = vcovCL(mod2, cluster=dat2$state1))  


predictions(mod, newdata="median", variables="afam")
avg_predictions(mod, newdata="median", variables="afam")



gmod <- glm(inews ~ college_ed + sex + sei10 + age, 
            data= gss16, family=binomial)

comps <- comparisons(gmod, newdata="median")
avg_comps <- avg_comparisons(gmod)

comps <- bind_rows(
  comps %>% as.data.frame() %>% mutate(type="comparisons"), 
  avg_comps %>% as.data.frame() %>% mutate(type = "avg_comparisons")
) %>% 
  mutate(tc = paste(term, contrast, sep=": "))

ggplot(comps, aes(x=estimate, xmin=conf.low, xmax=conf.high, y=tc, fill=type, color=type)) + 
  geom_bar(position="dodge", stat="identity", alpha=.15, color="transparent") + 
  geom_linerange(position=position_dodge(width=1))

## get data used in the model
tmp <- get_all_vars(formula(gmod), gss16)

is.binary <- function(x){
  x <- na.omit(x)
  is.numeric(x) & all(x %in% c(0, 1))
}

is.not_binary <- function(x){
  x <- na.omit(x)
  is.numeric(x) & !all(x %in% c(0, 1))
}


tmp <- get_all_vars(formula(gmod), gss16)

get_diff <- function(x, factor="pairwise", numeric="2sd"){
  {if(is.factor(x)){
    factor
  }else{
    if(is.binary(x)){
      c(0,1)
    }else{
      if(is.numeric(x)){
        numeric
      }else{
        NA
      }
    }
  }
  }
}

vbls <- lapply(tmp %>% select(-inews), get_diff)


comps <- comparisons(gmod, newdata="median", variables=vbls)
avg_comps <- avg_comparisons(gmod, variables=vbls)

comps <- bind_rows(
  comps %>% as.data.frame() %>% mutate(type="comparisons"), 
  avg_comps %>% as.data.frame() %>% mutate(type = "avg_comparisons")
) %>% 
  mutate(tc = paste(term, contrast, sep=": "))

ggplot(comps, aes(x=estimate, xmin=conf.low, xmax=conf.high, y=tc, fill=type, color=type)) + 
  geom_bar(position="dodge", stat="identity", alpha=.15, color="transparent") + 
  geom_linerange(position=position_dodge(width=1))


gmod <- glm(inews ~ college_ed + sex + sei10 + age, 
            data= gss16, family=binomial)

plot_predictions(gmod, condition="college_ed")
plot_predictions(gmod, condition="sei10")
plot_predictions(gmod, condition=list("sei10", "sex", "college_ed"))


avg_comparisons(mod, 
                newdata = datagrid(evyy=c(1975, 1988), grid_type="counterfactual"), 
                variables=list(afam = "minmax"), by="evyy")

avg_comparisons(mod, 
                newdata = datagrid(evyy=c(1975, 1988), grid_type="counterfactual"), 
                variables=list(afam = "minmax"), by="evyy", hypothesis = "b2-b1=0")

plot_comparisons(mod, variables="afam", by="evyy")

comps <- comparisons(mod, variables="afam")

ggplot(comps, aes(x=estimate)) + 
  geom_histogram() + 
  geom_vline(xintercept = 0.0720206, color="red") + 
  geom_vline(xintercept = 0.075, color="blue") 



gss16 <- gss16 %>% 
  mutate(sex = factorize(sex),
         tvnews = case_when(
           newsfrom == 5 ~ 1, 
           newsfrom %in% c(1:4, 6:10) ~ 0, 
           TRUE ~ NA_integer_))
         


gmod1 <- glm(inews ~ college_ed + sex + sei10 + age, 
            data= gss16, family=binomial)
gmod2 <- glm(tvnews ~ college_ed + sex + sei10 + age, 
             data= gss16, family=binomial)

preds1 <- avg_predictions(gmod1, variables="college_ed")
preds2 <- avg_predictions(gmod2, variables="college_ed")

preds <- bind_rows(
  preds1 %>% as.data.frame() %>% mutate(model = "Model 1"), 
  preds2 %>% as.data.frame() %>% mutate(model = "Model 2")
)

ggplot(preds, aes(x=college_ed, y=estimate, ymin=conf.low, ymax=conf.high, colour=model)) + 
  geom_pointrange(position = position_dodge(width=.5)) +
  theme_bw()

# shortcuts
# %>% : cmd + shioft + m (mac), ctrl + shift + m (windows)
# <- : option + - (mac), alt + - (windows)

library(survey)
load("~/Dropbox/rbe_2025/data/ces19.rda")

d <- svydesign(ids=~1, strata=~province19, weights=~weight_CES, data=ces19)
d
# svytable is the survey equivalent of xtabs()
svytable(~educ + province, design=d)

library(DAMisc)
xt(d, "educ")
xt(d, "educ", byvar="province")

GSS2016
GSS2016 <- read_dta("data/GSS2016.dta")

# aidhouse and partyid
GSS2016 %>% select(aidhouse, partyid) %>% str()
GSS2016 <- GSS2016 %>% 
  mutate(aidhouse = as_factor(aidhouse), 
         partyid=as_factor(partyid))

# weights: wtssnr, no strata

gss_des <- svydesign(ids = ~1, weights=~wtssnr, data=GSS2016)
xt(gss_des, "aidhouse")
xt(gss_des, "partyid")
xt(GSS2016, "partyid")

tab <- svytable(~aidhouse + partyid, design=gss_des)
tab <- as_tibble(tab) %>% 
  filter(!str_detect(aidhouse, "IAP|CANT|NA"), !str_detect(partyid, "NA|DK|other"))

tab <- tab %>% 
  group_by(partyid) %>% 
  mutate(pct = n/sum(n), 
         aidhouse = factor(aidhouse, levels = levels(GSS2016$aidhouse)), 
         partyid = factor(partyid, levels = levels(GSS2016$partyid))) 

ggplot(tab, aes(x=partyid, y=pct, fill=aidhouse)) + 
  geom_bar(stat="identity") + 
  theme_bw() + 
  coord_flip()

tab1 <- svytable(~jobspriv, design=d)
tab2 <- svytable(~blame, design=d)
tab3 <- svytable(~poorgap, design=d)
tab4 <- svytable(~stayhome, design=d)

tabs <- bind_rows(
tab1 %>% as_tibble() %>% rename(category = jobspriv) %>% mutate(vbl = "Gov Jobs"), 
tab2 %>% as_tibble() %>% rename(category = blame) %>% mutate(vbl = "Blame Self", category = rev(category)), 
tab3 %>% as_tibble() %>% rename(category = poorgap) %>% mutate(vbl = "Poor Gap"), 
tab4 %>% as_tibble() %>% rename(category = stayhome) %>% mutate(vbl = "Stay Home"))

tabs <- tabs %>% mutate(category = factor(category, levels=levels(ces19$blame)))
tabs <- tabs %>% group_by(vbl) %>% mutate(pct = n/sum(n))

ggplot(tabs, aes(x=vbl, y=pct, fill=category)) + 
  geom_bar(stat="identity") + 
  coord_flip()

GSS2016 <- read_dta("data/GSS2016.dta")

# aidhouse and partyid
GSS2016 %>% select(aidhouse, partyid) %>% str()
GSS2016 <- GSS2016 %>% 
  mutate(aidhouse = as_factor(aidhouse), 
         partyid=as_factor(partyid))

GSS2016 <- GSS2016 %>% 
  mutate(sex = factorize(sex),
         inews = case_when(
           newsfrom == 3 ~ 1, 
           newsfrom %in% c(1:2, 4:10) ~ 0, 
           TRUE ~ NA_integer_), 
         college_ed = case_when(
           educ <= 12 ~ "None", 
           educ %in% 13:15 ~ "Some", 
           educ >= 16 ~ "Degree", 
           TRUE ~ NA_character_), 
         college_ed = factor(college_ed, levels=c("None", "Some", "Degree"))) 

gss_des <- svydesign(ids = ~1, weights=~wtssnr, data=GSS2016)

tab <- svytable(~partyid + college_ed, design=gss_des)
tab <- as_tibble(tab) %>%  filter(!str_detect(partyid, "DK|NA"))
tab <- tab %>% group_by(partyid) %>% mutate(pct = n/sum(n))
ggplot(tab, aes(x=partyid, y=pct, fill=college_ed)) + 
  geom_bar(stat="identity") + 
  coord_flip()



## subpopulation analysis
load("data/ces19.rda")
library(survey)
d <- svydesign(ids=~1, strata=~province19, weights=~weight_CES, data=ces19)
svymean(~leader_lib, design=d, na.rm=TRUE)

# in stata
# svyset [pw=weight_CES], strata(province19)
# svy, subpop(gender): mean leader_lib


library(DAMisc)
sumStats(d, "leader_lib", byvar = "vote")

debugonce(chisq.test)

# install.packages("reprex")
library(reprex)

# normal: 
# dnorm - PDF
# pnorm - CDF
# qnrom - Inverse CDF (quantile)
# rnorm - random variate drawer



# q: how can I make a histogram in R?


# q: can you show me how to make a histogram of the hp variable in the mtcars data?
# A: Sure! You can use the `hist()` function in R to create a histogram. Here's how you can do it for the `hp` variable in the `mtcars` dataset:
hist(mtcars$hp, 
     main="Histogram of Horsepower", 
     xlab="Horsepower", 
     col="lightblue", 
     border="black")

# q: how can I make the histogram above in in ggplot2?
# A: You can use the `ggplot2` package to create a histogram with more customization options. Here's how you can do it for the `hp` variable in the `mtcars` dataset:
library(ggplot2)
ggplot(mtcars, aes(x=hp)) + 
  geom_histogram(binwidth=10, fill="lightblue", color="black") + 
  labs(title="Histogram of Horsepower", x="Horsepower") +
  theme_minimal()

# q: what if I wanted to change the color to red and make 10 bins?
# A: You can specify the number of bins directly in the `geom_histogram()` function by using the `bins` argument. Here's how you can do it:
ggplot(mtcars, aes(x=hp)) + 
  geom_histogram(bins=10, fill="red", color="black") + 
  labs(title="Histogram of Horsepower", x="Horsepower") +
  theme_minimal()

# attr(gss16$newsfrom, "labels")
# newspapers                    magazines 
# 1                            2 
# the internet books other printed material 
# 3                            4 
# tv                        radio 
# 5                            6 
# government agencies                       family 
# 7                            8 
# friends colleagues                        other 
# 9                           10 

gss16 <- gss16 %>% 
  mutate(media = case_when(
    newsfrom == 3 ~ "Internet", 
    newsfrom %in% c(1,2,4,5,6) ~ "legacy media", 
    newsfrom %in% c(7:10) ~ "other",
    TRUE ~ NA_character_ 
  ), 
  media = factor(media, levels=c("Internet", "legacy media", "other")))

ggplot(gss16, aes(x=media)) +
  geom_bar(fill="lightblue", color="black") + 
  labs(title="Proportion of News Sources", x="News Source", y="Proportion") +
  theme_minimal()

# q: Do I really need `aes(y=..prop.., group=1)` in the code above?
# A: Yes, you need `aes(y=..prop.., group=1)` to ensure that the y-axis represents the proportion of each category in the `media` variable.

# q: I made the plot without it and it worked fine, is it right?
# A: If you made the plot without `aes(y=..prop.., group=1)` and it worked fine, it likely defaulted to counting the number of occurrences in each category. However, if you want to explicitly show proportions, it's a good practice to include it. The `group=1` is used to ensure that ggplot treats the entire dataset as a single group when calculating proportions.

# q: how can I use case_when to recode a variable?
# A: You can use the `case_when()` function from the `dplyr` package to recode a variable based on specific conditions. Here's an example of how to use it:
library(dplyr)
# Let's say you have a variable `age` and you want to create a new variable `age_group`:
gss16 <- gss16 %>% 
  mutate(age_group = case_when(
    age < 18 ~ "Child",
    age >= 18 & age < 65 ~ "Adult",
    age >= 65 ~ "Senior",
    TRUE ~ NA_character_  # This handles any other cases, including NA
  ))
# This will create a new variable `age_group` based on the conditions specified.





