## R by Example
## Dave Armstrong
## ICPSR Summer Program
## June 6, 2025
## Day 5

## County boundary files from: https://www.census.gov/geographies/mapping-files/time-series/geo/carto-boundary-file.html

# install.packages("sf")
library(sf)
library(tidyverse)
library(haven)

polys <- read_sf("cb_2018_us_county_20m/cb_2018_us_county_20m.shp")
colo <- read_dta("data/colo_dat_cs.dta")
colo <- colo %>% 
  mutate(urban_rural = as_factor(urban_rural))
colo_polys <- polys %>% 
  left_join(colo, by = join_by(NAME == county))

colo_polys <- colo_polys %>% filter(STATEFP == "08")

# colo_polys <- colo_polys %>% 
#   mutate(mur = str_extract(urban_rural, "Metro|UP|Rural"), 
#          mur = factor(mur, levels=c("Rural", "UP", "Metro")))
         

## if error about invalid polygons 
colo_polys <- st_make_valid(colo_polys)
## if map renders slowly, try simplifying the geographies
colo_polys <- st_simplify(colo_polys, dTolerance = 0.01)

ggplot(colo_polys, aes(fill = urban_rural)) + 
  geom_sf() + 
  theme_void()

colo_polys %>% 
  mutate(mur = str_extract(urban_rural, "Metro|UP|Rural"), 
         mur = factor(mur, levels=c("Rural", "UP", "Metro"))) %>% 
  ggplot(aes(fill = mur)) + 
    geom_sf() + 
    theme_void()

ggplot(colo_polys, aes(fill = repvote)) + 
  geom_sf() + 
  scale_fill_gradient2(low = "blue", mid = "white", high = "red", midpoint = 0.5) + 
  theme_void()


colo_polys <- colo_polys %>%
  mutate(tooltip = paste0("County: ", NAME, "<br>",
                          "Rep Vote: ", sprintf("%.0f%%", repvote*100)))

g <- ggplot(colo_polys, aes(fill = repvote, text=tooltip)) + 
  geom_sf() + 
  scale_fill_gradient2(low = "blue", mid = "white", high = "red", midpoint = 0.5) + 
  labs(fill = "Republican\nVote") + 
  theme_void()

library(plotly)
ggplotly(g, tooltip="text") %>% style(hoveron = "fill")


# install.packages("leaflet")
# install.packages("htmltools")
library(leaflet)
library(htmltools)
colo_polys <- st_transform(colo_polys, "+proj=longlat +datum=WGS84")

pal <- colorNumeric("RdYlBu", 
                    domain = colo_polys$repvote)

## tooltips appear on hover
leaflet(colo_polys) %>%
  addTiles() %>%
  addPolygons(fillColor = ~pal(repvote),
              fillOpacity = 0.7,
              color = "white",
              weight = 1,
              label = ~lapply(paste0("County: ", NAME, "<br>",
                                     "Rep Vote: ", sprintf("%.0f%%", repvote*100)), HTML)) %>% 
  addLegend("bottomright", pal = pal, values = ~repvote,
            title = HTML("Republican<br>Vote"),
            opacity = 1) %>% 
  setView(lng = -105, lat = 39, zoom = 6)


## tooltips appear on click
htmlwidgets::saveWidget({
leaflet(colo_polys) %>%
  addTiles() %>%
  addPolygons(fillColor = ~pal(repvote),
              fillOpacity = 0.7,
              color = "white",
              weight = 1,
              popup = ~lapply(paste0("County: ", NAME, "<br>",
                                     "Rep Vote: ", sprintf("%.0f%%", repvote*100)), HTML)) %>% 
  addLegend("bottomright", pal = pal, values = ~repvote,
            title = HTML("Republican<br>Vote"),
            opacity = 1) %>% 
  setView(lng = -105, lat = 39, zoom = 6)}, "colo_map.html", selfcontained = TRUE)

mlbook <- rio::import("data/mlbook2_r.txt")


lmod <- lm(langPOST ~ IQ_verb + sex + Minority, data=mlbook)


## FE 
femod <- lm(langPOST ~ IQ_verb + sex + Minority + as.factor(schoolnr), data=mlbook)

library(broom)
tidy(femod) %>% 
  filter(!str_detect(term, "schoolnr"))


# install.packages("plm")
library(plm)
pdf <- pdata.frame(mlbook, index=("schoolnr"))

femod2 <- plm(langPOST ~ IQ_verb + sex + Minority, data=pdf, 
              model="within", effect="individual")

library(marginaleffects)
predictions(femod2, newdata=datagrid("median"), variables="IQ_verb")

# install.packages("lme4")
library(lme4)
remod <- lmer(langPOST ~ IQ_verb + sex + Minority + (1  | schoolnr), data=mlbook)

# install.packages("lmerTest")
library(lmerTest)
remod <- lmer(langPOST ~ IQ_verb + sex + Minority + (1  | schoolnr), data=mlbook)
# Satterthwaite DF
summary(remod)
# Kenward-Roger DF
summary(remod, ddf="Kenward-Roger")
# No DF 
summary(remod, ddf="lme4")

b <- coef(remod)
## distribution of random intercepts
ggplot(b$schoolnr, aes(x=`(Intercept)`)) + geom_histogram()

library(marginaleffects)

preds <- predictions(remod, newdata=datagrid(schoolnr= sample(unique(mlbook$schoolnr), 10)), variables="IQ_verb")
ggplot(preds, aes(x=IQ_verb, y=estimate, group = schoolnr)) + 
  geom_line() + 
  theme_bw()

remod2 <- lmer(langPOST ~ IQ_verb + sex + Minority + (1+ IQ_verb| schoolnr), data=mlbook)

preds2 <- predictions(remod2, newdata=datagrid(schoolnr= sample(unique(mlbook$schoolnr), 100)), variables="IQ_verb")
ggplot(preds2, aes(x=IQ_verb, y=estimate, group = schoolnr)) + 
  geom_line() + 
  theme_bw()

ggplot(coef(remod2)$schoolnr, aes(x=IQ_verb)) + geom_histogram()



bes <- read_dta("bes_panel.dta")
bes <- bes %>% 
  pivot_longer(-c(id, gender), names_pattern = "(.*)W(\\d*)", 
               names_to = c(".value", "wave")) %>%
  mutate(wave = as.numeric(wave))

bes <- bes %>% 
  mutate(trustMPs = case_when(trustMPs > 10~ NA_integer_, 
                              TRUE ~ trustMPs), 
         taxSpendSelf = case_when(taxSpendSelf > 10 ~ NA_integer_, 
                                  TRUE ~ taxSpendSelf), 
         gender = as_factor(gender), 
         p_edlevel = as_factor(p_edlevel)) %>% 
  drop_na() 

library(lme4)
mod <- lmer(taxSpendSelf ~ trustMPs + gender*wave + (1 + wave | id), 
            data = bes, REML=TRUE)


mod <- lmer(scale(taxSpendSelf) ~ scale(trustMPs) + gender*scale(wave) + (1 + scale(wave) | id), 
            data = bes, REML=TRUE)

library(marginaleffects)
preds <- predictions(mod, newdata = datagrid(id = sample(unique(bes$id), 100, replace=FALSE), 
                                             wave = sort(unique(bes$wave))))


ggplot(preds, aes(x=wave, y=estimate, group=id)) + 
  geom_line()


mod2 <- lmer(scale(taxSpendSelf) ~ scale(trustMPs) + gender + scale(wave) +
             I(scale(wave)^2)  + (1 + scale(wave) + I(scale(wave)^2) | id), 
            data = bes, REML=TRUE)

library(marginaleffects)
preds <- predictions(mod, newdata = datagrid(id = sample(unique(bes$id), 100, replace=FALSE), 
                                             wave = sort(unique(bes$wave))))


ggplot(preds, aes(x=wave, y=estimate, group=id)) + 
  geom_line()



preds2 <- predictions(mod, newdata = datagrid(id = NA, 
                                              wave = sort(unique(bes$wave)), 
                                              gender = c("Male", "Female")), 
                      re.form=NA)

plot_predictions(mod, newdata = datagrid(id = NA), 
            condition = c("wave", "gender"), re.form=NA)


library(GPArotation)


## You are interested in the following: how does relative trust in social and traditional media affect 
## voting for Donald Trump in 2024?  If you're running a model, you may want to control for things like 
## age, education, gender, class, etc...  How would you convey your findings?


searchVarLabels(anes, "trust")


search_mult <- function(data, ...){
  args <- list(...)[[1]]
  if(length(args) < 2)
    stop("Use searchVarLabels() for only one search term.\n")
  out <- lapply(args, \(x)searchVarLabels(data, x))
  ints <- intersect(rownames(out[[1]]), rownames(out[[2]]))
  if(length(out) > 2){
    for(i in 2:length(out)){
      ints <- intersect(ints, rownames(out[[i]]))
    }
  }
  if(length(ints) > 0){
    DAMisc::searchVarLabels(data, paste(ints, collapse="|"))
  } else{
    stop("No variables found matching all terms.\n")
  }  
}

search_mult(anes, c("trust", "media"))



d <- data.frame(x= c(-1, -2, 1, 2, 3, 4), y = factor(c(-1,1,2,2,3,3), levels=c(-1,1:3), labels=c("Inap", "Low", "Med", "High")))

d %>% 
  mutate(new_x = case_when(
    x < 0 ~ NA_character_, 
    x %in% 1:2 ~ "Low", 
    TRUE ~ x
  ))

d %>% 
  mutate(new_y = case_when(
    y == "Inap" ~ NA_character_, 
    y %in% c("Low", "Med") ~ "Low", 
    TRUE ~ y
  ))


anes <- read_dta("anes_timeseries_2024_stata_20250430/anes_timeseries_2024_stata_20250430.dta")

library(DAMisc)
searchVarLabels(anes, "vote")

## You are interested in the following: how does relative trust in social and traditional media affect 
## voting for Donald Trump in 2024?  If you're running a model, you may want to control for things like 
## age, education, gender, class, etc...  How would you convey your findings?

anes <- anes %>% 
  mutate(trump_vote = case_when(
    V242067 == 2 ~ 1, 
    V242067 %in% c(1,3,4,5,6) ~ 0, 
    TRUE ~ NA_integer_), 
    trust_trad_media = case_when(
      V242422 < 0 ~ NA_integer_, 
      TRUE ~ 5-V242422), 
    trust_social_media = case_when(
      V242423 < 0 ~ NA_integer_, 
      TRUE ~ 5-V242423), 
    diff_trust = case_when(
      trust_social_media > trust_trad_media ~ 1, 
      trust_trad_media > trust_social_media ~ 2, 
      trust_trad_media == trust_social_media & trust_trad_media %in% 1:2 ~ 3, 
      trust_trad_media == trust_social_media & trust_trad_media %in% 3:4 ~ 4,
      TRUE ~ NA_integer_), 
    diff_trust = factor(diff_trust, 
                        levels = c(1, 2, 3, 4), 
                        labels = c("Social Media > Traditional Media", 
                                   "Traditional Media > Social Media", 
                                   "Equal Trust (Low)", 
                                   "Equal Trust (High)")), 
    pol_interest = case_when(
      V242400 < 0 ~ NA_character_, 
      V242400 %in% 1:2 ~ "Interested", 
      V242400 %in% 3:4 ~ "Not Interested"),
    pol_interest = factor(pol_interest, levels=c("Not Interested", "Interested")), 
    gender = case_when(
      V241551 == 1 ~ "Man", 
      V241551 == 2 ~ "Woman", 
      V241551 %in% c(3,4) ~ "Non-Binary/Other", 
      TRUE ~ NA_character_), 
    gender = factor(gender, levels=c("Man", "Woman", "Non-Binary/Other")), 
    age = case_when(
      V241458x < 0 ~ NA_integer_, 
      TRUE ~ V241458x), 
    degree = case_when(
      V241463 %in% 13:16 ~ "Degree", 
      V241463 %in% 1:12 ~ "No Degree",
      TRUE ~ NA_character_), 
    degree = factor(degree, levels=c("No Degree", "Degree")), 
    class = case_when(
      V242338 == 1 ~ "Lower", 
      V242338 == 2 ~ "Middle", 
      V242338 == 3 ~ "Upper", 
      TRUE ~ NA_character_), 
    class = factor(class, levels=c("Lower", "Middle", "Upper")))


library(survey)
des <- svydesign(ids =~1, strata=~V240107d, weights=~V240107b, data=filter(anes, !is.na(V240107b)))

cc <- complete.cases(des$variables %>% select(trump_vote, diff_trust, pol_interest, gender ,age, degree, class))

mod <- svyglm(trump_vote ~ diff_trust*pol_interest + gender + age + degree + class, 
              design=subset(des, cc), family=binomial)


library(marginaleffects)
preds <- avg_predictions(mod, variables=c("diff_trust", "pol_interest"), wts=weights(mod$survey.design))
plot_predictions(mod, condition = c("diff_trust", "pol_interest")) + 
  theme(legend.position = "top", 
        axis.text.x = element_text(angle=45, hjust=1))

avg_comparisons(mod, variables="pol_interest", by="diff_trust", wts = weights(mod$survey.design))

comps2 <- avg_comparisons(mod, variables=list("diff_trust"="pairwise"), 
                          by="pol_interest",
                          wts = weights(mod$survey.design))
